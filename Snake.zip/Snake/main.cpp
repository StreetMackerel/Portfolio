#include <iostream>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;
bool gameOver;
const int width = 20;
const int height = 20;
int x,y,tokenX,tokenY,score;
int tailX[width*height],tailY[width*height];
int tailSize;

enum eDir {STOP = 0, LEFT, RIGHT, UP, DOWN};
eDir dir;

void Setup()
{
    gameOver=false;
    x = width/2;
    y = height/2;
    tokenX = rand()%width;
    tokenY = rand()%height;
    score=0;
}
void Draw()
{

    system("cls"); // clears the screen

    for(int i = 0; i < width+2; i++)
        cout << "#";
        cout << endl;


    for(int i = 0; i< height; i++)
    {
        for(int j = 0; j< width; j++)
        {
            if(j==0)
                cout<<"#";
            if(i==y && j==x) //if coords are at head
                cout<<"0";
            else if(i==tokenY && j==tokenX)
                cout<<"X";
            else
            {
             bool drawTail = false;
               for(int z = 0; z<tailSize; z++) //draw tail
               {

                    if(tailX[z] == j && tailY[z] == i)
                    {

                        cout << "o";
                        drawTail = true;
                    }

               }
                if(!drawTail)
                        cout<<" ";
            }


            if(j == width - 1)
                cout<<"#";
        }
        cout<<endl;
    }

    for(int i = 0; i< width+2; i++)
        cout << "#";
        cout << endl;
        cout<< "Score: "<< score << endl;
}

void Input()
{
    if(_kbhit())
    {
        switch (_getch())
        {
         case 'w' :
             dir = UP;
             break;
         case 'a' :
             dir = LEFT;
             break;
         case 's' :
             dir = DOWN;
             break;
         case 'd' :
             dir = RIGHT;
             break;
         case 'x' :
             gameOver = true;
             break;
         default:
             break;
        }
    }
}
void Logic()
{
    int prevX = tailX[0];
    int prevY = tailY[0];
    int prevX2, prevY2;
    tailX[0]=x;
    tailY[0]=y;
    for(int i = 1; i<tailSize; i++)
    {
        prevX2 = tailX[i];
        prevY2 = tailY[i];
        tailX[i] = prevX;
        tailY[i] = prevY;
        prevX = prevX2;
        prevY = prevY2;
    }

    switch(dir)
    {
    case LEFT:
        x--;
        break;
    case RIGHT:
        x++;
        break;
    case UP:
        y--;
        break;
    case DOWN:
        y++;
        break;
    }

   // if(x > width || x < 0 || y > height || y < 0) //game over if head exits grid
   //     gameOver = true;

    if(x >= width) x=0; else if (x<0) x = width-1; // go through walls
    if(y >= height) y=0; else if (y<0) y = height-1;

    for(int i = 0;i<tailSize; i++) // check for tail collisions
        if(tailX[i] == x && tailY[i] == y)
            gameOver = true;

    if(x == tokenX && y == tokenY) // token collisions
       {
        score++;
        tokenX = rand()%width;
        tokenY = rand()%height;
        tailSize++;
       }
}
int main()
{
    Setup();
    while(!gameOver)
    {
        Draw();
        Input();
        Logic();
        Sleep(10);
    }
}
